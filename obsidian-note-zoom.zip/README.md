# Note Zoom

Zoom in and out within notes using the provided commands with this plugin. 

To match default Obsidian shortcuts, bind "Zoom in" to (Ctrl + Shift + =), "Zoom out" to (Ctrl + Shift + -). 

By default, the zoom level is stored in the note's properties, and by default this property is hidden. Both of the afforementioned features may be altered in the plugin's settings.